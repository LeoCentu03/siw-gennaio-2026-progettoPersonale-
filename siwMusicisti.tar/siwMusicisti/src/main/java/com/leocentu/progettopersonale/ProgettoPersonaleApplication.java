package com.leocentu.progettopersonale;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgettoPersonaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgettoPersonaleApplication.class, args);
	}

}
