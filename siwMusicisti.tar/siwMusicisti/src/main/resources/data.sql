INSERT INTO credenziali (id, username, password, ruolo) VALUES (1, 'francesco', 'ciao', 'MUSICISTA');
INSERT INTO credenziali (id, username, password, ruolo) VALUES (2, 'mario24', 'ciao', 'MUSICISTA');
INSERT INTO credenziali (id, username, password, ruolo) VALUES (3, 'cristina17', 'ciao', 'UTENTE');
INSERT INTO credenziali (id, username, password, ruolo) VALUES (4, 'viola12', 'ciao', 'UTENTE');

INSERT INTO utente (id, nome, cognome, data_nascita, credenziali_id) VALUES (1, 'Cristina', 'Verdi', '2001-10-22', 3);
INSERT INTO utente (id, nome, cognome, data_nascita, credenziali_id) VALUES (2, 'Viola', 'Rossi', '2004-10-22', 4);

INSERT INTO musicista (id, nome, cognome, data_nascita, voto_totale, credenziali_id) VALUES (1, 'Francesco', 'Bianchi', '2001-12-06', 0, 1);
INSERT INTO musicista (id, nome, cognome, data_nascita, voto_totale, credenziali_id) VALUES (2, 'Mario', 'Rossi', '2001-03-09', 7, 2);

INSERT INTO album (id, titolo, testo, voto, musicista_id) VALUES (1, 'The Dark Side of the Moon', 'Speak to Me, Breathe, Time, Money, Us and Them', 0, 1);
INSERT INTO album (id, titolo, testo, voto, musicista_id) VALUES (2, 'Thriller', 'Wanna Be Startin Somethin, Thriller, Beat It, Billie Jean', 0, 1);
INSERT INTO album (id, titolo, testo, voto, musicista_id) VALUES (3, 'A Night at the Opera', 'Bohemian Rhapsody, Love of My Life, You''re My Best Friend', 7, 2);

INSERT INTO votazione (id, mittente_id, destinatario_id, album_id, voto) VALUES (1, 3, 2, 3, 7);

SELECT setval('credenziali_id_seq', (SELECT MAX(id) FROM credenziali));
SELECT setval('utente_id_seq', (SELECT MAX(id) FROM utente));
SELECT setval('musicista_id_seq', (SELECT MAX(id) FROM musicista));
SELECT setval('album_id_seq', (SELECT MAX(id) FROM album));
SELECT setval('votazione_id_seq', (SELECT MAX(id) FROM votazione));