package com.leocentu.progettopersonale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettoPersonaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
